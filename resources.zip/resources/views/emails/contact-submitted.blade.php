<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form Submission</title>
</head>

<body>
    <p>Dear {{ $contact->name }},</p>

    <p>Thank you for reaching out to us. Here are the details of your submission:</p>

    <p>We will review your message and get back to you shortly.</p>

    <p>Best regards,<br>
   Hidgar</p>
</body>

</html>
